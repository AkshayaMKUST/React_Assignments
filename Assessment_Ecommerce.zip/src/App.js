import React from 'react';
import ProductDetails from './Product/Product';
import productData from './ProductData/ProductData';
import "./App.css";

function App() {

  const productComponents = productData.map(product => <ProductDetails id={product.id} name={product.name} category={product.category} price={product.price} description={product.description} rating={product.rating} image={product.image} />)
  return (
    <div>
      <h1>VioMart</h1>
      <div className="App">
        {productComponents}
      </div>
    </div>
  );
}

export default App;
