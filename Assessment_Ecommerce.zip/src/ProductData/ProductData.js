const productData=[
  {
    "id": 1,
    "name": "HP Pavilion 39.6 cm Laptop",
    "category": "Laptop",
    "description": "Powerful laptop for all your computing needs.",
    "price": 999.99,
    "image": "https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/c/0/c07961307.png",
    "rating": 4.5
  },
  {
    "id": 2,
    "name": "Iphone 13 256gb",
    "category": "Smartphone",
    "description": "Feature-rich smartphone with the latest technology.",
    "price": 499.99,
    "image": "https://th.bing.com/th/id/R.f7725a434a1cc84ff279e2919daee6d1?rik=7tsryuoZq9Lb1g&riu=http%3a%2f%2fpngimg.com%2fuploads%2fiphone_12%2fiphone_12_PNG20.png&ehk=9yDm5iWbFQ89tvKT0cgjFq7Jpb2GCf5H08v7E7Myo4c%3d&risl=&pid=ImgRaw&r=0",
    "rating": 4.2
  },
  {
    "id": 3,
    "name": "Nike Running Shoes",
    "category": "Running Shoes",
    "description": "Comfortable running shoes for your active lifestyle.",
    "price": 79.99,
    "image": "https://assetscdn1.paytm.com/images/catalog/product/F/FO/FOONIKE-RUNALLDSMAR262972E61C911/0..jpg",
    "rating": 4.7
  },
  {
    "id": 4,
    "name": "Philips Coffee Maker",
    "category": "Home & Kitchen",
    "description": "Enjoy a perfect cup of coffee with this advanced coffee maker.",
    "price": 129.99,
    "image": "https://tse1.mm.bing.net/th/id/OIP.s_mgmwIO-_DM0HCqEfkmIgHaJQ?rs=1&pid=ImgDetMain",
    "rating": 4.0
  },
  {
    "id": 5,
    "name": "American Tourister Backpack",
    "category": "Fashion",
    "description": "Stylish and functional backpack for everyday use.",
    "price": 49.99,
    "image": "https://tse1.mm.bing.net/th/id/OIP.mRdb_3K_7XetlonnsiBazAHaIg?rs=1&pid=ImgDetMain",
    "rating": 4.3
  },
  {
    id: 6,
    name: "Impex Iron Box",
    category: "Home Appliances",
    price: 49.99,
    description: "Powerful and efficient iron box for your everyday ironing needs.",
    rating: 4.6,
    image: "https://tse2.mm.bing.net/th/id/OIP.Svi3GLkZKWOr0CEtl8B_nQHaGG?rs=1&pid=ImgDetMain",
  },
  {
    id: 7,
    name: "Philips Vacuum Cleaner",
    category: "Home Appliances",
    price: 129.99,
    description: "Keep your home clean with this high-performance vacuum cleaner. Perfect for all types of floors.",
    rating: 4.3,
    image: "https://tse2.mm.bing.net/th/id/OIP.4jg3v43pGU6-NL0kzGsnlAHaJc?rs=1&pid=ImgDetMain",
  },
  {
    id: 9,
    name: "PS4 PlayStation",
    category: "Electronics",
    price: 399.99,
    description: "Experience gaming like never before with the latest PlayStation console. Includes cutting-edge features and graphics.",
    rating: 4.8,
    image: "https://tse3.mm.bing.net/th/id/OIP.w-RFUnftWrwsYref9dxqqgHaHO?w=1080&h=1053&rs=1&pid=ImgDetMain",
  },
  {
    id: 9,
    name: "Samsung OLED TV",
    category: "Electronics",
    price: 599.99,
    description: "Immerse yourself in stunning visuals and crystal-clear sound with this state-of-the-art television.",
    rating: 4.7,
    image: "https://tse2.mm.bing.net/th/id/OIP.2ecrLXjxbt-z-grtBr6v-gHaE3?rs=1&pid=ImgDetMain",
  }
]
export default productData;

