import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Login/Login';
import Dashboard from './Dashboard/Dashboard';
import Profile from './Profile/Profile';
import Hooks from './Hooks/Hooks';
import { UserProvider } from './UserContext';

const App = () => {
  return (
    <UserProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/hooks" element={<Hooks />} />
          </Routes>
        </Router>
    </UserProvider>
  );
};

export default App;
