import React from 'react'
import { useState, useRef } from 'react';

function Hooks() {
  return (
    <div>
      <StateComponent/>
      <RefComponent/>
    </div>
  )
}

export default Hooks;

const StateComponent = () => {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <h2>Component with useState</h2>
      <p>Count: {count}</p>
      <button onClick={handleIncrement}>Increment</button>
    </div>
  );
};


const RefComponent = () => {
  const countRef = useRef(0);

  const handleIncrement = () => {
    countRef.current += 1;
    console.log('Current count (via useRef):', countRef.current);
  };

  return (
    <div>
      <h2>Component with useRef</h2>
      <p>Count (via useRef): {countRef.current}</p>
      <button onClick={handleIncrement}>Increment</button>
    </div>
  );
};

  //Here when the button is clicked, it modify countRef.current without re-rendering. 
  // This allows us to maintain state without causing the component to re-render.