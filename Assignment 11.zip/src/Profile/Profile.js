import { useContext, useEffect, useReducer } from 'react';
import UserContext from '../UserContext';

const useUserProfile = () => {
  const { username } = useContext(UserContext);

  const initialState = {
    loading: true,
    userData: null,
  };

  const reducer = (state, action) => {
    switch (action.type) {
      case 'SUCCESS':
        return {
          loading: false,
          userData: action.payload,
        };
      case 'ERROR':
        return {
          loading: false,
          userData: null,
        };
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://run.mocky.io/v3/14eb76d4-bd74-497f-bc17-1aff31b686d5');
        const data = await response.json();
        dispatch({ type: 'SUCCESS', payload: data });
      } catch (error) {
        console.error('Error fetching data:', error);
        dispatch({ type: 'ERROR' });
      }
    };

    fetchData();
  }, []);

  return { username, ...state };
};

export default useUserProfile;
