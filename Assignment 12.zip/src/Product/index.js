import Product from "./Product";
export default Product;
