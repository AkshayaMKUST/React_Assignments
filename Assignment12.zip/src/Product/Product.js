import React, { useState } from 'react';
import './Product.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import productData from '../ProductData/ProductData';

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha384-dfLKVpqtINNBVDSxlaB6eF5q6IWlhfakg8M1JA+z3DgqqOep8Dg8nqV3Zd0yIpe4" crossorigin="anonymous" />


const ProductDetails = (props) => {
  const [showDetails, setShowDetails] = useState(false);
  const [heartFilled, setHeartFilled] = useState(false);

  const toggleDetails = () => {
    setShowDetails(!showDetails);
  };

  const handleHeartClick = () => {
    setHeartFilled(!heartFilled);
  };

  const handleCartClick = () => {
    alert(`Product "${props.name}" added to the shopping cart`);
  };
  const handleShare = () => {
    alert(`Product "${props.name}" link has been shared`);
  };


  return (
    <div className={`product ${showDetails ? 'show-details' : ''}`}>
      <div className="product-card">
        <img src={props.image} className="product-image" alt={props.name} />
        <div className="product-details">
          <h3 className="product-name">{props.name}</h3>
          <p className="product-category">{props.category}</p>
          <p className="product-price">${props.price}</p>
          <div className="product-rating">
            <span>Rating:</span>
            <span className="rating-value">{props.rating}/5</span>
          </div>
          <div className="dropdown">
            <button className="dropdown-btn" onClick={toggleDetails}>
              {showDetails ? 'Hide Details' : 'Show Details'}
            </button>
            {showDetails && (
              <div className="dropdown-content">
                <p className="product-description">{props.description}</p>
              </div>
            )}
          </div>
          <div className="icons">
            <button
              className={`heart-icon ${heartFilled ? 'filled' : ''}`}
              onClick={handleHeartClick}
            >
              <i className="fas fa-heart"></i>
            </button>
            <button className="cart-icon" onClick={handleCartClick}>
              <i className="fas fa-shopping-cart"></i>
            </button>
            <button className="share-icon" onClick={handleShare}>
              <i className="fa-regular fa-share-from-square"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
const productComponents = productData.map(product => <ProductDetails id={product.id} name={product.name} category={product.category} price={product.price} description={product.description} rating={product.rating} image={product.image} />)
 

export default productComponents;
