import ProductData from "./ProductData";
export default ProductData;
