const authenticateUser = (email, password) => {
  // for retrieving existing users
  const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
  const userExists = existingUsers.some(
    (user) => user.email === email && user.password === password
  );
  return userExists;
};

const storeUserDetails = (email, password) => {
  const existingUsers = JSON.parse(localStorage.getItem('users')) || [];
  const isEmailRegistered = existingUsers.some((user) => user.email === email);

  if (isEmailRegistered) {
    return { success: false, message: 'Email is already registered.' };
  }
  // Adding new user details
  const newUser = { email, password };
  existingUsers.push(newUser);
  localStorage.setItem('users', JSON.stringify(existingUsers));

  return { success: true, message: 'User successfully registered.' };
};

export { storeUserDetails };
export { authenticateUser };