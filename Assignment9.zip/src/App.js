import React from "react";
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom";
import Registration from "./Register/Register";
import Login from "./Login/Login";
import Dashboard from "./Dashboard/Dashboard";

function App() {
  return (
    <Router>
      <Link to="/registration">
        <h4 className='App'>Click to Register</h4>
      </Link>
      <Routes>
        <Route path="/registration" element={<Registration />} />
        <Route path="/login" element={<Login/>}/>
        <Route path="/dashboard" element={<Dashboard/>}/>
      </Routes>
    </Router>
  );
}

export default App;
