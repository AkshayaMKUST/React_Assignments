import React, { useState } from 'react';
import MovieList from './MovieList';
import { List, ListItem, Typography } from '@mui/material';
import './Dashboard.css';

const movies = [
  { id: 1, name: 'Bramayugam', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/25/Bramayugam_Official_Poster.jpg/330px-Bramayugam_Official_Poster.jpg', language: 'Malayalam', genre: 'Horror', releaseDate: '2024-02-02' },
  { id: 2, name: 'Premalu', image: 'https://tse1.mm.bing.net/th/id/OIP.VaSEHwe-Qw77SpBTNrfivQAAAA?rs=1&pid=ImgDetMain', language: 'Malayalam', genre: 'Comedy', releaseDate: '2024-02-08' },
  { id: 3, name: 'Manjummal Boys', image: 'https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/manjummel-boys-et00386670-1707452965.jpg', language: 'Malayalam', genre: 'Thriller', releaseDate: '2024-02-21' },
  { id: 4, name: 'Teri Baaton Mein Aisa Uljha Jiya', image: 'https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/teri-baaton-mein-aisa-uljha-jiya-et00383266-1705300344.jpg', language: 'Hindi', genre: 'Comedy', releaseDate: '2024-02-09' },
  { id: 5, name: 'Dunki', image: 'https://tse4.mm.bing.net/th/id/OIP.EOkc75GCtLq7n4o_A_R4pQHaJQ?rs=1&pid=ImgDetMain', language: 'Hindi', genre: 'Drama', releaseDate: '2024-02-21' }
];

const Dashboard = () => {
  const [selectedMovie, setSelectedMovie] = useState(null);

  const handleMovieClick = (movie) => {
    setSelectedMovie(movie);
  };

  return (
    <div className="dashboard">
      <div className="sidebar">
        <Typography variant="h5">Top Movies</Typography>
        <List component="nav">
          {movies.map((movie) => (
            <ListItem
              key={movie.id}
              className="movie-list-item"
              onClick={() => handleMovieClick(movie)}
              button
            >
              {movie.name}
            </ListItem>
          ))}
        </List>
      </div>
      <div className="content">
        {selectedMovie ? (
          <div className="movie-details">
            <img src={selectedMovie.image} alt={selectedMovie.name} />
            <div>
              <Typography variant="h4">{selectedMovie.name}</Typography>
              <Typography>Language: {selectedMovie.language}</Typography>
              <Typography>Genre: {selectedMovie.genre}</Typography>
              <Typography>Release Date: {selectedMovie.releaseDate}</Typography>
            </div>
          </div>
        ) : (
          <Typography>Select a movie from the list to view details.</Typography>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
