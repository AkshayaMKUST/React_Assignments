
import React from 'react';
import "./Dashboard.css"

const MovieList = ({ movies, onMovieClick }) => {
  return (
    <ul className="movie-list">
      {movies.map((movie) => (
        <li key={movie.id} className="movie-list-item" onClick={() => onMovieClick(movie)}>
          {movie.name}
        </li>
      ))}
    </ul>
  );
};

export default MovieList;
