import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Link as RouterLink } from 'react-router-dom';
import {
  Container,
  Typography,
  TextField,
  Button,
  Box,
  Paper,
  Link,
} from '@mui/material';
import './Login.css';

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    navigate('/dashboard');
  };

  return (
    <Container className="loginContainer login">
      <Paper elevation={3} className="loginForm logindiv">
        <Box p={3}>
          <Typography variant="h5" align="center">
            Login
          </Typography>
          <form id="loginForm" onSubmit={handleLogin}>
            <table className="formTable">
              <tbody>
                <tr>
                  <td colSpan="2">
                    <TextField
                    label="Username"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    name="username"
                    id="username"
                   />
                  </td>
                </tr>
                <tr>
                  <td colSpan="2">
                    <TextField
                      label="Password"
                      fullWidth
                    margin="normal"
                      name="password"
                      id="password"
                      variant="outlined"
                      // style={{ padding: '10px', marginBottom: '15px', borderRadius: '15px', fontSize: '16px', width: '100%' }}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
            <Button
              style={{
                backgroundColor: 'rgb(226, 217, 224)',
                color: 'rgb(80, 35, 125)',
                padding: '8px',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '16px',
                transition: 'background-color 0.3s',
                margin: '0 auto',
                justifyContent: 'center',
                alignItems: 'center',
                display: 'flex',
                outline: '2px solid',
                outlineColor: 'rgb(127, 55, 138)',
              }}
              type="submit"
            >
              SIGN IN
            </Button>
          </form>

          <Box style={{ margin: '15px 0' }}>
            <Typography variant="h6">
              <Link href="#" style={{ textDecoration: 'none', color: '#bf45c8', fontSize: 'smaller'}}>
                Forgot Password?
              </Link>
            </Typography>
            <Typography variant="h6">
              Don't have an account?{' '}
              <Link component={RouterLink} to="/registration" style={{ textDecoration: 'none', color: '#bf45c8', fontSize: 'smaller' }}>
                Register
              </Link>
            </Typography>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default Login;
