import React from 'react';
import {
  TextField,
  Button,
  Radio,
  RadioGroup,
  FormControlLabel,
  Checkbox,
} from '@mui/material';
import './Register.css';

const Registration = () => {
  return (
    <div>
      <div className="regdiv">
        <h2 style={{ textAlign: 'center' }}>Register</h2>
        <form id="regform" action="">
          <TextField
            label="First Name"
            variant="outlined"
            fullWidth
            margin="normal"
            name="firstname"
            id="firstname"
            style={{ marginBottom: '5px' }}
          />
          <TextField
            label="Last Name"
            variant="outlined"
            fullWidth
            margin="normal"
            name="lastname"
            id="lastname"
            style={{ marginBottom: '5px' }}
          />
          <TextField
            label="Email"
            variant="outlined"
            fullWidth
            margin="normal"
            type="email"
            name="email"
            id="email"
            required
            style={{ marginBottom: '5px' }}
          />
          <TextField
            label="Password"
            variant="outlined"
            fullWidth
            margin="normal"
            type="password"
            name="password"
            id="pass"
            required
            style={{ marginBottom: '5px' }}
          />
          <TextField
            label="Confirm Password"
            variant="outlined"
            fullWidth
            margin="normal"
            type="password"
            name="confirmPassword"
            id="confirmPassword"
            required
            style={{ marginBottom: '5px' }}
          />
          <TextField
            label="Date of Birth"
            variant="outlined"
            fullWidth
            margin="normal"
            type=""
            name="dob"
            id="dob"
            required
            style={{ marginBottom: '5px' }}
          />
          <RadioGroup row aria-label="gender" name="gender" defaultValue="Male">
            <FormControlLabel
              value="Male"
              control={<Radio />}
              label="Male"
              style={{ marginBottom: '20px' }}
            />
            <FormControlLabel
              value="Female"
              control={<Radio />}
              label="Female"
              style={{ marginBottom: '20px' }}
            />
            <FormControlLabel
              value="Others"
              control={<Radio />}
              label="Others"
              style={{ marginBottom: '20px' }}
            />
          </RadioGroup>
          <FormControlLabel
            control={<Checkbox name="condition" id="condition" />}
            label="I accept the terms and conditions"
            style={{ justifyContent: 'left', width: 'fit-content' }}
          />
          <br />
          <br />
          <Button
            variant="contained"
            color="primary"
            type="submit"
            className="sub"
            style={{
              backgroundColor: 'rgb(224, 200, 226)',
              outline: '2px solid',
              outlineColor: 'rgb(136, 69, 130)',
              color: 'rgb(113, 25, 91)',
              margin: '0 auto',
              display: 'flex',
              padding: '12px',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '16px',
              transition: 'background-color 0.3s',
            }}
          >
            Submit
          </Button>
        </form>
        <h4 style={{ textAlign: 'center', fontFamily: 'Josefin Sans, sans-serif' }}>
          Already have an account? <a href="login">Login</a>
        </h4>
      </div>
    </div>
  );
};

export default Registration;
