
import React from "react";
import "./App.css"
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom"
import LifecycleComponent from "./LifecycleComponent/LifecycleComponent";

function App() {
  return (
    <Router>
    <div className="App">
      <Link to="/update">Update</Link>
      <Routes>
        <Route path="/update" element={<LifecycleComponent/>}/>
      </Routes>
    </div>
    </Router>
  );
}

export default App;
