import React, { Component } from 'react';
import "./LifecycleComponent.css"

class LifecycleComponent extends Component {
  constructor(props) {
    super(props);
    console.log('Constructor called');
    this.state = {
      message: 'Hello, Good Morning!!',
    };
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('shouldComponentUpdate called');
    return true;
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('componentDidUpdate called');
  }

  componentDidMount() {
    console.log('componentDidMount called');
  }

  componentWillUnmount() {
    console.log('componentWillUnmount called');
  }

  componentDidCatch(error, info) {
    console.log('componentDidCatch called');
    console.error(error);
  }

  handleClick = () => {
    this.setState({ message: 'Have a nice day!!' });
  };

  render() {
    console.log('Render called');
    return (
      <div>
        <p>{this.state.message}</p>
        <button onClick={this.handleClick}>Update Message</button>
      </div>
    );
  }
}

export default LifecycleComponent;
