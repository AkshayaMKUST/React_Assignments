import LifecycleComponent from "./LifecycleComponent";
export default LifecycleComponent;
