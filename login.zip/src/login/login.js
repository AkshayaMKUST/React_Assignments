import "./login.css";
import React,{useState} from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const navigate = useNavigate();

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  // Password regex: Minimum 6 characters, at least one uppercase letter, one lowercase letter, and one number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;

  const handleEmailChange = (e) => {
    const inputEmail = e.target.value;
    setEmail(inputEmail);

    // Email validation using regex
    setEmailError(inputEmail.trim() === '' ? '' :emailRegex.test(inputEmail) ? '' : 'Invalid email address');
  };

  const handlePasswordChange = (e) => {
    const inputPassword = e.target.value;
    setPassword(inputPassword);

    // Password validation using regex
    setPasswordError(inputPassword.trim() === '' ? '' : passwordRegex.test(inputPassword) ? '' : 'Password must be at least 6 characters, including one uppercase letter, one lowercase letter, and one number');
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form before submitting
    if (emailError === '' && passwordError === '') {
      // Your login logic here
      console.log('Login successful!');
      navigate("/welcome");
    } else {
      console.log('Form is not valid. Please check your inputs.');
    }
  };

  return (
    <div className="login">
      <div className="login-body">

      
      <h1>Login</h1>
      
      <div className="login-form">
      <form action="" onSubmit={handleSubmit}>
        <table>
        <tr>
            <td colSpan={2}>{emailError && <span>{emailError}</span>}</td>
          </tr>
          <tr>
            <td><label htmlFor="email">Email</label></td>
            <td><input type="email" id="email" name="email" value={email} required onChange={handleEmailChange}/></td>
          </tr>
          <tr>
            <td><label htmlFor="password">Password</label></td>
            <td><input type="password" id="password" name="password" value={password} required onChange={handlePasswordChange}/></td>
          </tr>
          <tr>
            <td colSpan={2}>{passwordError && <span>{passwordError}</span>}</td>
          </tr>
        </table>
        <button type="submit">Login</button>
      </form>
      </div>
      </div>
    </div>
  );
};

export default Login;
