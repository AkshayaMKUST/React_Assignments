import React from "react";

const About = () =>{
    return(
        <h3>All about me</h3>
        
    );
}
export default About;