import React from 'react';
import './Home.css'; 
const Home = () => {
    return(
        <body>
            <div className='homeDiv'>
        <h2>Welcome to Home Page</h2>
        <h3>Greetings!!!</h3>
    </div>
    </body>
        
    );
}
export default Home;