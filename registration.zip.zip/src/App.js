import React from 'react';
import "./App.css";
import Register from './components/Register.js';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

function App() {
  return (
    <Router>
      <Link to="/registration">
        <h4 className='App'>Click to Register</h4>
      </Link>
      <Routes>
        <Route path="/registration" element={<Register />} />
      </Routes>
    </Router>
  );
}

export default App;
