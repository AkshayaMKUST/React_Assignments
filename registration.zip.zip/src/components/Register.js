import React from "react";
import './Register.css';

function Register() {
    return (

        <div className="regdiv">
            <h2>Register</h2>
            <form id="regform" action="">
            <label htmlFor="firstname">FirstName : </label>
            <input type="text" name="firstname" id="firstname" />
            <label htmlFor="lastname">Lastname : </label>
            <input type="text" name="lastname" id="lastname" />
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required="" />
            <label for="password">Password</label>
            <input type="password" name="password" id="pass" required="" />
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required="" />
            <label for="dob">Date of Birth</label>
            <input type="date" name="dob" id="dob" required="" />
            <label for="gender">Gender</label>
            <input class="radio" type="radio" value="Male" name="gender" id="male"/>Male
            <input class="radio" type="radio" value="Female" name="gender" id="female"/>Female
            <input class="radio" type="radio" value="Others" name="gender" id="other"/>Others
            <br />
            <input class="condition" type="checkbox" name="" id="condition"/>I accept the terms and conditions
            <br/>
            <br/>
            <button class="sub" type="submit">Submit</button>
            </form>
            <h4>Already have an account? <a href="login.html">Login</a></h4>
        </div>

            );
}
export default Register;