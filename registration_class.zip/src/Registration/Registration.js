import React, { Component } from "react";
import "./Registration.css";

class RegistrationFunction extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        name: "",
        age: 0,
        company: "",
      },
      inputValues: {
        name: "",
        age: "",
        company: "",
      },
      submitted: false,
    };
  }

  handleInputChange = (e) => {
    if (e.target) {
      const { name, value } = e.target;
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          [name]: value,
        },
        inputValues: {
          ...prevState.inputValues,
          [name]: value,
        },
      }));
    }
  };

  handleSubmit = (e) => {
    e.preventDefault();
    this.setState({ submitted: true });
  };

  render() {
    const { formData, inputValues, submitted } = this.state;

    return (
      <div className="registration-function">
        <div className="regheading">
          <h1>Registration-function</h1>
        </div>
        <div className="regform">
          <form onSubmit={this.handleSubmit}>
            <table>
              <tbody>
                <tr>
                  <td>
                    <label htmlFor="name">Name </label>
                  </td>
                  <td>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      value={formData.name}
                      onChange={this.handleInputChange}
                    />
                    <span>{inputValues.name}</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <label htmlFor="age">Age </label>
                  </td>
                  <td>
                    <input
                      type="number"
                      name="age"
                      id="age"
                      value={formData.age}
                      onChange={this.handleInputChange}
                    />
                    <span>{inputValues.age}</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <label htmlFor="company">Company </label>
                  </td>
                  <td>
                    <input
                      type="text"
                      name="company"
                      id="company"
                      value={formData.company}
                      onChange={this.handleInputChange}
                    />
                    <span>{inputValues.company}</span>
                  </td>
                </tr>
              </tbody>
            </table>
            <button className="" type="submit">
              Publish
            </button>
          </form>
        </div>
        {submitted && (
          <div className="welcome">
            <div className="box">
              <h2>Welcome</h2>
              <br />
              <h4>Hi {formData.name} !!</h4>
              <h4>You are {formData.age} and working in {formData.company}!!</h4>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default RegistrationFunction;
