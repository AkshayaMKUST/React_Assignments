import "./Welcome.css";
import React from "react";

function template() {
  return (
    <div className="welcome">
      <h1>Welcome</h1>
    </div>
  );
};

export default template;
