import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import RegistrationFunction from "./Registration_function/Registration-function";

function App() {


  return (
    <Router>
      <nav>
        <ul>
          <li>
            <Link to="/registration">Go to Register</Link>
          </li>
        </ul>
      </nav>

      <Routes>
        <Route
          path="/registration"
          element={<RegistrationFunction/>}
        />
      </Routes>
    </Router>
  );
}

export default App;
