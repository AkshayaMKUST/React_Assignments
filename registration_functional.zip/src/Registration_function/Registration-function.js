import React, { useState } from "react";
import "./Registration-function.css";

const RegistrationFunction = () => {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    company: "",
  });

  

  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (e) => {
    if (e.target) {
      const { name, value } = e.target;
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
      
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="registration-function">
      <div className="regheading">
        <h1>Registration-function</h1>
      </div>
      <div className="regform">
        <form onSubmit={handleSubmit}>
          <table>
            <tbody>
              <tr>
                <td>
                  <label htmlFor="name">Name </label>
                </td>
                <td>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                  <span>{formData.name}</span>
                </td>
              </tr>
              <tr>
                <td>
                  <label htmlFor="age">Age </label>
                </td>
                <td>
                  <input
                    type="number"
                    name="age"
                    id="age"
                    value={formData.age}
                    onChange={handleInputChange}
                  />
                  <span>{formData.age}</span>
                </td>
              </tr>
              <tr>
                <td>
                  <label htmlFor="company">Company </label>
                </td>
                <td>
                  <input
                    type="text"
                    name="company"
                    id="company"
                    value={formData.company}
                    onChange={handleInputChange}
                  />
                  <span>{formData.company}</span>
                </td>
              </tr>
            </tbody>
          </table>
          <button className="" type="submit">
            Publish
          </button>
        </form>
      </div>
      {submitted && (
        <div className="welcome">
          <div className="box">
            <h2>Welcome</h2>
            <br />
            <h4>Hi {formData.name} !!</h4>
            <h4>You are {formData.age} and working in {formData.company}!!</h4>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrationFunction;
