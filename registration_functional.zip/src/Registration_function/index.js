import Registration-function from "./Registration-function";
export default Registration-function;
